CREATE table Student_tbl(studentroll number(6) primary key,studentname varchar2(15),dob DATE);
INSERT into student_tbl values(1001,'Ajay','JAN-12-2001');
INSERT into student_tbl values(1002,'Abcd','DEC-01-1995');

INSERT into student_tbl values(1003,'xyz','DEC-01-1996');