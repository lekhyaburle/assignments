package com.student.dao;

public interface IQueryMapper {
	public static final String viewAll="SELECT studentroll,studentname,dob FROM Student_tbl";
}
