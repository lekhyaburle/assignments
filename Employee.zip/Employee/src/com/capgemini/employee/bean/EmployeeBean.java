package com.capgemini.employee.bean;

public class EmployeeBean {
	private int id;
	private String name;
	private int salary;
	private String doj;
	private String DeptName;
	private String Designation;
	
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getDeptName() {
		return DeptName;
	}
	public void setDeptName(String deptName) {
		DeptName = deptName;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}

	public EmployeeBean(String name, int salary, String doj,
			String deptName, String designation) {
		super();
		
		this.name = name;
		this.salary = salary;
		this.doj = doj;
		DeptName = deptName;
		Designation = designation;
	}

	public EmployeeBean() {
		super();
	}

	@Override
	public String toString() {
		return "EmployeeBean [id=" + id + ", name=" + name + ", salary="
				+ salary + ", doj=" + doj + ", DeptName=" + DeptName
				+ ", Designation=" + Designation + "]";
	}
	
	
}
