package com.capgemini.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.util.DBConnection;

public class EmployeeDAOImpl implements IEmployeeDAO {

	@Override
	public int insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		int records =0 ;
		boolean isInserted = false;
		int empId = 0;
		try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
						connEmployeeDetails.prepareStatement(QueryMapperEmployees.INSERT_EMPLOYEE);){
		
			
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			String strDate=employeeBean.getDoj();
			TemporalAccessor ta=dtf.parse(strDate);
			LocalDate localDate = LocalDate.from(ta);
			java.sql.Date doj=java.sql.Date.valueOf(localDate);
			preparedStatement.setString(1, employeeBean.getName());
			preparedStatement.setInt(2, employeeBean.getSalary());
			preparedStatement.setDate(3,doj);
			preparedStatement.setString(4, employeeBean.getDeptName());
			preparedStatement.setString(5, employeeBean.getDesignation());
			
			records = preparedStatement.executeUpdate();
			if(records >0 ){
				isInserted = true;
				 preparedStatement=connEmployeeDetails.prepareStatement(QueryMapperEmployees.SELECT_EMPID);
				
				
				
			}
			
		}catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage());
		}
		return empId;
	}

	@Override
	public boolean deleteEmployee(int empId) throws EmployeeException {
		int records =0 ;
		boolean isDeleted = false;
		try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
						connEmployeeDetails.prepareStatement(QueryMapperEmployees.DELETE_EMPLOYEE);){
			
			preparedStatement.setInt(1, empId);
			
			
			records = preparedStatement.executeUpdate();
			
			
			if(records >0 ){
				isDeleted = true;
			}
		
		}catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage());
		}
		
		return isDeleted;	
	}

	/*@Override
	public List<EmployeeBean> viewEmployees() throws EmployeeException {
		List<EmployeeBean>employeeList=new ArrayList<EmployeeBean>();
		try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
						connEmployeeDetails.prepareStatement(QueryMapperEmployees.VIEW_ALL);
				ResultSet rsEmployees = preparedStatement.executeQuery();){
		
			while(rsEmployees.next()){
				EmployeeBean employee = new EmployeeBean();
				employee.setId(rsEmployees.getInt("empId"));
				employee.setName(rsEmployees.getString("empName"));
				employee.setSalary(rsEmployees.getInt("salary"));
				employee.setDeptName(rsEmployees.getString("DepartmentName"));
				employee.setDesignation(rsEmployees.getString("Designation"));
				employeeList.add(employee);
			
			}
			
			if(employeeList.size() == 0){
				throw new EmployeeException("No records found.");
			}
			
		}catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage());
		}
		return employeeList;
		
		
	}
*/
	@Override
	public boolean updateEmployee(int empId, int salary)
			throws EmployeeException {
	
		int records =0 ;
		boolean isUpdated = false;
		
		try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
						connEmployeeDetails.prepareStatement(QueryMapperEmployees.UPDATE_EMPLOYEE);){
			preparedStatement.setInt(1, salary);
			
			preparedStatement.setInt(2, empId);
			
			records = preparedStatement.executeUpdate();
			if(records >0 ){
				isUpdated = true;
			}
			
			
		}catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage());
		}
		
		return isUpdated;
	}

}
