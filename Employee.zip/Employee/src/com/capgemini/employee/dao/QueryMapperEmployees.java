package com.capgemini.employee.dao;

public interface QueryMapperEmployees {
	
	public static final String INSERT_EMPLOYEE="INSERT INTO EMPLOYEES VALUES(EmployeeIdSequence.NEXTVAL,?,?,?,?,?)";
	public static final String DELETE_EMPLOYEE="DELETE FROM EMPLOYEES WHERE empId=?";
	public static final String SELECT_EMPID="SELECT empId FROM EMPLOYEES WHERE name=?";
	//public static final String VIEW_ALL="SELECT * FROM EMPLOYEES";
	public static final String UPDATE_EMPLOYEE="UPDATE EMPLOYEES SET SALARY=? WHERE empId=?";
}
