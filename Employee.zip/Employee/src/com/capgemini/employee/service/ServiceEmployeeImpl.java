package com.capgemini.employee.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.dao.EmployeeDAOImpl;
import com.capgemini.employee.dao.IEmployeeDAO;
import com.capgemini.employee.exception.EmployeeException;

public class ServiceEmployeeImpl implements IServiceEmployee {

	@Override
	public boolean insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		boolean isItInserted =false;
		try{
		IEmployeeDAO employeeDAO=new EmployeeDAOImpl();
	
		 isItInserted = employeeDAO.insertEmployee(employeeBean);
		}catch(EmployeeException e){
			throw new EmployeeException(e.getMessage());
		}
		return isItInserted;
	}

	@Override
	public boolean deleteEmployee(int empId) throws EmployeeException {
		boolean isDeleted=false;
		
		try{
		IEmployeeDAO employeeDAO=new EmployeeDAOImpl();
		isDeleted=employeeDAO.deleteEmployee(empId);
		
	}catch(EmployeeException e){
			throw new EmployeeException(e.getMessage());
		}
		
		return isDeleted;
	}

	@Override
	public boolean updateEmployee(int empId, int salary)
			throws EmployeeException {
		boolean isUpdated=false;
		try{
			IEmployeeDAO employeeDAO=new EmployeeDAOImpl();
			isUpdated=employeeDAO.updateEmployee(empId, salary);
			
			
		}catch(EmployeeException e){
			throw new EmployeeException(e.getMessage());
		}
		
		return isUpdated;
	}
	
	
	public boolean isValidName(String name)throws EmployeeException{
		boolean isValid=false;
		
		String pattern="[A-Z]{1}[A-Za-z]{1,19}";
		Pattern pattern1 = Pattern.compile(pattern);
		Matcher matcher = pattern1.matcher(name);
	isValid=	matcher.matches();
	
		if(!isValid){
			throw new EmployeeException("Invalid Name ");
		}
		return isValid;
	}
	
	public boolean isValidSalary(int salary)throws EmployeeException{
		boolean isValid=false;
		if(salary<0){
			isValid=false;
		}
		else isValid=true;
		return isValid;
	}
	
}
