package com.capgemini.employee.service;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;

public interface IServiceEmployee {
	public boolean insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException;
	public boolean deleteEmployee(int empId) throws EmployeeException;
	public boolean updateEmployee(int empId,int salary)throws EmployeeException;
	
}
