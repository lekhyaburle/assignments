package com.capgemini.employee.pi;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.service.ServiceEmployeeImpl;

public class EmployeeMain {

	
		private static Logger logger=Logger.getRootLogger();
		
		
		public static void main(String[] args) {
			PropertyConfigurator.configure("resources/log4j.properties");
			boolean isInProcess = true;
			byte choice=0;
			 int id;
			 String name = null;
			 int salary = 0;
			 String doj;
		 	 String DeptName;
			 String Designation;
			
			boolean isValid=false;
			EmployeeBean employeeBean=null;
			ServiceEmployeeImpl serviceEmployee=new ServiceEmployeeImpl();
			Scanner scInput=new Scanner(System.in);
			while(isInProcess){
				System.out.println("1)Insert Employee Details");
				System.out.println("2)Delete Employee Details");
				System.out.println("3)Update Employee Details");
				System.out.println("0)Exit");
				System.out.println("Enter the Required Choice");
				
				choice=Byte.parseByte(scInput.nextLine());
				switch(choice){
				case 1:
					isValid=false;
					while(!isValid){
						try{
					  System.out.println("Enter employee name");
					  name=scInput.nextLine();
					  isValid=serviceEmployee.isValidName(name);
					    }catch(EmployeeException ee){
					    	logger.error("Invalid name:"+name);
					    	System.err.println("Invalid name:"+name);
					       isValid=false;	
					    }
					}
					
					isValid=false;
					while(!isValid){
						try{
							System.out.println("Enter Salary");
							salary=scInput.nextInt();
							scInput.nextLine();
							isValid=serviceEmployee.isValidSalary(salary);
					
						}catch(EmployeeException ee){
							logger.error("Invalid Salary:"+salary);
							System.err.println("Salary should be greater than 0");
							isValid=false;
						}
						
					}
					System.out.println("Enter Hire Date");
					doj=scInput.nextLine();
					System.out.println("Enter Department Name");
					DeptName=scInput.nextLine();
					System.out.println("Enter Designation");
					Designation=scInput.nextLine();
					
					employeeBean=new EmployeeBean(name,salary,doj,DeptName,Designation);
					try{
						boolean inserted=false;
						inserted=serviceEmployee.insertEmployee(employeeBean);
						if(inserted){
							System.out.println("Inserted Successfully");
							}
							
						}catch(EmployeeException e){
							logger.error(e.getMessage());
							System.err.println(e.getMessage());
						}
					break;
				case 2:
					
					isValid=false;
					while(!isValid){
						
					  System.out.println("Enter Employee Id");
					  id=Integer.parseInt( scInput.nextLine());
					try{
						isValid =serviceEmployee.deleteEmployee(id);
					
						System.out.println("Employee is deleted successfully!!!");
					
					}catch(EmployeeException e){
						logger.error(e.getMessage());
						System.err.println(e.getMessage());
						isValid=false;
					}					
					}
					break;
				case 3:
					isValid=false;
					while(!isValid){
						System.out.println("Enter Employee Id");
						id=Integer.parseInt( scInput.nextLine());
						System.out.println("Enter Salary");
						salary=Integer.parseInt( scInput.nextLine());
						try{
						 isValid=serviceEmployee.updateEmployee(id, salary);
						if(isValid){
							System.out.println("Updated Successfully");}
						}catch(EmployeeException e){
						logger.error(e.getMessage());
						System.err.println(e.getMessage());
						isValid=false;
					}
					}				
					break;
				case 0:
					isInProcess=false;
					break;
					default:
						
						System.out.println("Invalid Input");
						logger.error("Invalid input:"+choice);
						System.err.println("Invalid input:"+choice);
						
				}
								
			}
			
		scInput.close();
	}

}
