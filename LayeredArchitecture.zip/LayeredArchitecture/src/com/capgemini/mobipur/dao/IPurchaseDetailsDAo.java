package com.capgemini.mobipur.dao;

import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;

public interface IPurchaseDetailsDAo {
	//inserting function
	public boolean insertPurchase(final PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException;
		
	//deletion of mobile
	public boolean deletePurchaseDetails(final int mobileId)
	throws MobilePurchaseException;
}
