import java.util.Scanner;

public class StringPositive {

	public static void main(String[] args) {
		
		String str;
		boolean status=false;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a string");
		str=sc.nextLine();
		str=str.toUpperCase();
		int length=str.length();
		for(int i = 0; i < length-1; ++i){
			if(str.charAt(i)>str.charAt(i+1)){
				status=true;
				break;
			}
		}
		
		if(status==false){
			System.out.println("Positive String");
		}else{
			System.out.println("Negative String");
		}
		sc.close();
	}

}
