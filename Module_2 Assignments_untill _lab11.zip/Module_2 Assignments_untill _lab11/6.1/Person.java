import java.time.LocalDate;
import java.time.Period;

public class Person {
	private String firstName;
	private String lastName;
	private String fullName;
	private Gender gender;
	private long phoneNumber;
	private int age;
	
	//Default Constructor
	public Person(){
		
	}
		
	//Parameterized Constructor
	public Person(String firstName, String lastName, Gender gender) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	} 
	
	//Getter and Setter
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public void setPhoneNumber(long num){
		this.phoneNumber=num;
	}
	
	//Function to calculate Age of person
	public void calculateAge(LocalDate birthDate){
		
		LocalDate currentDate = LocalDate.now();
		Period period = birthDate.until(currentDate);
		this.age = period.getYears();
	}
	
	//Function to append first name and last name
	public void setFullName(String fname, String lname)throws InvalidNameException{
		if(fname.equals("") && lname.equals("")){
			throw new InvalidNameException("Name Cann't be empty");
		}
		fname=fname.concat(" ");
		this.fullName = fname.concat(lname);
	}
	//Output Function
	public void output(){
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("Full Name: "+fullName);
		System.out.println("Gender: "+gender);
		System.out.println("Phone Number: "+phoneNumber);
		System.out.println("Age: "+age);
	}
	
}
