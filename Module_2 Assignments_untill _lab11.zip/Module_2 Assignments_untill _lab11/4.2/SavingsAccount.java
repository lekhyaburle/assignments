
public class SavingsAccount extends Account {
	
	private final double minBalance=500;
	
	public SavingsAccount(){
		super();
	}
	
	public SavingsAccount(double balance, Person accHolder){
		super(balance,accHolder);
	}
	
	public boolean withdraw(double amount){
		double newBalance;
		if(this.getBalance()-amount>minBalance){
			newBalance=this.getBalance()-amount;
			this.setBalance(newBalance);
			return true;
		}else{
			return false;
		}
	}
}
