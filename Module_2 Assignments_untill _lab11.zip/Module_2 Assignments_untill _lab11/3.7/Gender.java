package com.capgemini.l3;

public enum Gender {
	M,F
}
