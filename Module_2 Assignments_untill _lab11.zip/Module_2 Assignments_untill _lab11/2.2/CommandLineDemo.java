public class CommandLineDemo {

	public static void main(String[] args) {
		int number;
		number=Integer.parseInt(args[0]);
		if(number > 0){
			System.out.println(number +" is a positive integer.");
		}else{
			System.out.println(number+" is a negative number");
		}

	}

}