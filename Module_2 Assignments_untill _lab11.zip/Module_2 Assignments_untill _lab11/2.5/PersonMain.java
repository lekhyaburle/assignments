package com.capgemini.assign;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		Person2 Person;
		String fname = null;
		String lname = null;
		Gender gender;
		
		Scanner scanf = new Scanner(System.in);
		
		System.out.println("Enter the First Name: ");
		fname = scanf.nextLine();
		System.out.println("Enter the Last Name: ");
		lname = scanf.nextLine();
		
		
		try {
			
			if(fname.length()==0 && lname.length()==0) {
				throw new Exception();
				
			}
	} catch(Exception e) {
		System.err.println("Error: First name and Last Name both cannot be empty\n");
		e.printStackTrace();
		System.exit(1);
	}
		
		
		System.out.println("Enter the phone number: ");
		String phone = scanf.nextLine();
		
		gender = Gender.F;
		
		Person = new Person2(fname,lname,gender,phone);
		
		System.out.println(Person);
		
		scanf.close();
	}
	
}