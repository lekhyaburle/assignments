package com.capgemini.assign;

public enum Gender {
	M,F
}
