package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.ClinicException;


/*****************************************************************
 *  - Interface Name:IPatientDAO 
 *  - Input Parameters : 
 *  - Return Type :
 *  - Throws : ClinicException 
 *  - Author : LekhyaBurle 
 *  - Creation Date : 22/11/2017
 *  - Description : Interface for DAO Layer
 *******************************************************************/

public interface IPatientDAO {
	public int addPatientDetails(PatientBean patient)throws ClinicException;
	public PatientBean getPatientDetails(int patientId)throws ClinicException;
	
	}
