package com.capgemini.tcc.bean;

import java.sql.Date;


public class PatientBean {
	private int patientId;
	private String patientName;
	private int age;
	private String description;
	private String phone;
	private Date consultationDate;
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	
	public Date getConsultationDate() {
		return consultationDate;
	}
	public void setConsultationDate(Date consultationDate) {
		this.consultationDate = consultationDate;
	}
	public PatientBean( String patientName, int age,
			String description, String phone) {
		super();
		this.patientName = patientName;
		this.age = age;
		this.description = description;
		this.phone = phone;
		
	}
	public PatientBean() {
		super();
	}
	@Override
	public String toString() {
		return "PatientBean [patientId=" + patientId + ", patientName="
				+ patientName + ", age=" + age + ", description=" + description
				+ ", phone=" + phone + ", consultationDate=" + consultationDate
				+ "]";
	}
	
	
	
}
