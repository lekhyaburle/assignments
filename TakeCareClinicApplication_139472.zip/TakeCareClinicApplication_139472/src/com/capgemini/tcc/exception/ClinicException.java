package com.capgemini.tcc.exception;

public class ClinicException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4082931196011827244L;

	public ClinicException() {
		super();
		
	}

	public ClinicException(String message) {
		super(message);
		
	}

	
	
}
