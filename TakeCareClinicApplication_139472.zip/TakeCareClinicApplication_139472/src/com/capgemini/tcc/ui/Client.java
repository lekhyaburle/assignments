package com.capgemini.tcc.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.ClinicException;
import com.capgemini.tcc.service.PatientService;

public class Client {
	private static Logger logger=Logger.getRootLogger();
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("resources/log4j.properties");
		boolean isInProcess = true;
		byte choice=0;
		String patientName = null;
		int age = 0;
		String description;
		String phone = null;
		boolean isValid=false;
		PatientBean patientBean = null;
		PatientService patientservice = new PatientService();
		Scanner scInput=new Scanner(System.in);
		while(isInProcess){
			System.out.println("1)Add Patient Information");
			System.out.println("2)Search by Patient Id");
			System.out.println("3)Exit");
			System.out.println("Enter the Required Choice");
			
			choice=Byte.parseByte(scInput.nextLine());
			switch(choice){
			case 1:
				isValid=false;
				while(!isValid){
					try{
				  System.out.println("Enter the name of the Patient");
				  patientName=scInput.nextLine();
				  isValid=patientservice.isValidName(patientName);
				    }catch(ClinicException e){
				    	logger.error("Invalid name:"+patientName);
				    	System.err.println("Invalid name:"+patientName);
				       isValid=false;	
				    }
				}
				
				isValid=false;
				while(!isValid){
					try{
						System.out.println("Enter Patient Age");
						age=scInput.nextInt();
						scInput.nextLine();
						isValid=patientservice.isValidAge(age);
				
					}catch(ClinicException e){
						logger.error("Invalid Age:"+age);
						System.err.println("Age should be greater than 0");
						isValid=false;
					}
					
				}
				System.out.println("Enter Description");
				description=scInput.nextLine();
				isValid=false;
				while(!isValid){
					try{
				System.out.println("Enter Patient Phone Number");
				phone=scInput.nextLine();
				isValid=patientservice.isValidPhone(phone);
					}catch(ClinicException e){
						logger.error("Invalid Phone number:"+phone);
						System.err.println("Phone number Should contain 10 digits");
						isValid=false;
					}
					
				}
				patientBean=new PatientBean(patientName, age, description, phone);
				try{
					int patientId=0;
					patientId=patientservice.addPatientDetails(patientBean);
					
						System.out.println("Inserted Successfully "+patientId);
											
					}catch(ClinicException e){
						logger.error(e.getMessage());
						System.err.println(e.getMessage());
					}
				break;
			case 2:
				
				isValid=false;
				int patientId=0;
						while(!isValid){
											try{
						System.out.println("Enter Patient Id");
						  patientId=Integer.parseInt(scInput.nextLine());
						isValid=patientservice.isValidPatientId(patientId);
						 if (isValid){
						PatientBean patient = patientservice.getPatientDetails(patientId);
						
							System.out.println("Name of the Patient: "
									+ patient.getPatientName());
							System.out.println("Age: " + patient.getAge());
							System.out.println("Phone Number: " + patient.getPhone());
							System.out.println("Description: "
									+ patient.getDescription());
							String date = patient.getConsultationDate().toString();
							System.out.println("Consultation Date:"
									+ date.substring(0, 10));
							isValid=true;
						 }
						 
						 }catch (ClinicException e) {
							 logger.error(e.getMessage());
						System.err.println(e.getMessage());
						isValid=false;
					}
						}
				
				break;
			case 3:
				isInProcess=false;
				break;
				default:
					System.out.println("Invalid Input");
					logger.error("Invalid input:"+choice);
					System.err.println("Invalid input:"+choice);
							}
		}
		scInput.close();
	}

}
