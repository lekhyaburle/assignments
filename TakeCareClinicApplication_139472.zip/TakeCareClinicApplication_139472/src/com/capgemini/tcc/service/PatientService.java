package com.capgemini.tcc.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.ClinicException;

public class PatientService implements IPatientService {
	/*****************************************************************
	 *  - Method Name:addPatientDetails 
	 *  - Input Parameters : PatientBean
	 *  - Return Type : integer
	 *  - Throws : ClinicException 
	 *  - Author : LekhyaBurle 
	 *  - Creation Date : 22/11/2017
	 *  - Description : Adds Patient Details into the DataBase by calling DAO Implementation
	 *******************************************************************/
	@Override
	public int addPatientDetails(PatientBean patient) throws ClinicException {
		IPatientDAO patientDAO=new PatientDAO();
		int patientId=patientDAO.addPatientDetails(patient);
		return patientId;	
	}

	/*****************************************************************
	 *  - Method Name:getPatientDetails 
	 *  - Input Parameters : patientId(integer Type)
	 *  - Return Type : PAatientBean
	 *  - Throws : ClinicException 
	 *  - Author : LekhyaBurle 
	 *  - Creation Date : 22/11/2017
	 *  - Description : search Patient Details by PatientId  by calling DAO Implementation
	 *******************************************************************/
	
	
	@Override
	public PatientBean getPatientDetails(int patientId) throws ClinicException {
		IPatientDAO patientDAO=new PatientDAO();
		PatientBean patient=patientDAO.getPatientDetails(patientId);
		return patient;
	}
	public boolean isValidName(String name)throws ClinicException {
boolean isValid=false;
		
		String pattern="[A-Z]{1}[A-Za-z]{1,19}";
		Pattern pattern1 = Pattern.compile(pattern);
		Matcher matcher = pattern1.matcher(name);
	isValid=	matcher.matches();
	
		if(!isValid){
			throw new ClinicException("Invalid Name ");
		}
		
		return isValid;
	}

	public boolean isValidAge(int age)throws ClinicException {
		boolean isValid=false;
				
				if(age>0){
					isValid=true;
				}
				if(!isValid){
					throw new ClinicException("Age should be greater than 0 ");
				}
				
				return isValid;
			}
	public boolean isValidPhone(String phone)throws ClinicException {
		boolean isValid=false;
				
		String pattern="\\d{10}";
		Pattern pattern1 = Pattern.compile(pattern);
		Matcher matcher = pattern1.matcher(phone);
	isValid=	matcher.matches();
				if(!isValid){
					throw new ClinicException("Invalid Phone number(should contain 10 digits) ");
				}
				
				return isValid;
			}
	
	public boolean isValidPatientId(int patientId)throws ClinicException{
		boolean isValid=false;
		if(patientId>=1000){
			isValid=true;
		}
		if(!isValid){
			throw new ClinicException("There is no patient with this Id");
		}
		return isValid;
	}
	
}
