package com.cg.dao;

import java.util.HashMap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;

public class EmployeeDaoImpl implements IEmployeeDao{
	private HashMap<Integer, Employee> empList=new HashMap<>();
	
	public HashMap<Integer, Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(HashMap<Integer, Employee> empList) {
		this.empList = empList;
	}

	@Override
	public Employee getEmployeeById(int id) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		empList=(HashMap<Integer, Employee>) ctx.getBean("daoImpl");
		Employee emp=empList.get(id);
		return emp;
	}

}
