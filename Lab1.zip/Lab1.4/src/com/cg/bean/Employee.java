package com.cg.bean;

public class Employee {
	private int employeeId;
	private int age;
	private String employeeName;
	private double salary;
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(int employeeId, int age, String employeeName, double salary) {
		super();
		this.employeeId = employeeId;
		this.age = age;
		this.employeeName = employeeName;
		this.salary = salary;
	}
	public Employee() {
		super();
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", age=" + age
				+ ", employeeName=" + employeeName + ", salary=" + salary + "]";
	}

	
	
}
