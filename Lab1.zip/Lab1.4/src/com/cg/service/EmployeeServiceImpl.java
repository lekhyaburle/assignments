package com.cg.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDaoImpl;
import com.cg.dao.IEmployeeDao;

public class EmployeeServiceImpl {


	public Employee getEmployeeById(int id){
		//ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
			IEmployeeDao employeeDao=new EmployeeDaoImpl();
			//employeeDao=(EmployeeDaoImpl) ctx.getBean("daoImpl");	
			Employee emp=employeeDao.getEmployeeById(id);
		return emp;
	}

	
	
	
}
