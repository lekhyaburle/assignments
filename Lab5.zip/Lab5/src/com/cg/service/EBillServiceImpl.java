package com.cg.service;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public class EBillServiceImpl implements IEBillService {

	@Override
	public boolean insert(BillDTO billDTO) throws BillUserException {
		return false;
	}

}
