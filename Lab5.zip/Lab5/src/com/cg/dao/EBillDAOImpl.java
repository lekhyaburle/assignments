package com.cg.dao;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public class EBillDAOImpl implements IEBillDAO {

	@Override
	public boolean insert(BillDTO billDTO) throws BillUserException {

		return false;
	}

}
