package com.capgemini.mobipur.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.cab.bean.PurchaseDetailsBean;
import com.capgemini.cab.exception.MobilePurchaseException;
import com.capgemini.cab.service.IServicePurchaseMobile;
import com.capgemini.cab.service.ServicePurchaseImpl;

public class ServicePurchaseImplTest {

	private PurchaseDetailsBean purchaseDetailsBean;
	
	@Before
	public void setUp() throws Exception {
		 purchaseDetailsBean = new PurchaseDetailsBean("abc","abcd@ab.com","9989002233",1002);
	}

	@After
	public void tearDown() throws Exception {
		purchaseDetailsBean = null;
	}

	@Test
	public final void testInsertPurchaseDetails() {
		IServicePurchaseMobile servicePurchaseMobile = new ServicePurchaseImpl();
		try{
		assertTrue(servicePurchaseMobile.insertPurchaseDetails(purchaseDetailsBean));
	}catch(MobilePurchaseException e){
		e.printStackTrace();
	}
	}

}
