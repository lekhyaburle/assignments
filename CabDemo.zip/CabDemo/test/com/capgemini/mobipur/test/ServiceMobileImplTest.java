package com.capgemini.mobipur.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.cab.bean.MobileBean;
import com.capgemini.cab.exception.MobilePurchaseException;
import com.capgemini.cab.service.IServiceMobile;
import com.capgemini.cab.service.ServiceMobileImpl;

public class ServiceMobileImplTest {
	private IServiceMobile serviceMobile;
	@Before
	public void setUp() throws Exception {
		serviceMobile = new ServiceMobileImpl();
	}

	@After
	public void tearDown() throws Exception {
		serviceMobile = null;
	}

	@Test
	public final void testSearch() {
		try{
		List<MobileBean>mobileList = serviceMobile.search(15000, 50000);
		assertTrue("No Such mobile",mobileList.size()>0);
		}catch(MobilePurchaseException e){
			e.printStackTrace();
		}
		
		
	}

}
