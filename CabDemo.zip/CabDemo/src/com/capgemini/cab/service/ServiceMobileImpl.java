package com.capgemini.cab.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cab.bean.MobileBean;
import com.capgemini.cab.dao.ICustomerDAO;
import com.capgemini.cab.dao.IPurchaseDetailsDAo;
import com.capgemini.cab.dao.MobileDAOImpl;
import com.capgemini.cab.dao.PurchaseDetailsDAOImpl;
import com.capgemini.cab.exception.MobilePurchaseException;

public class ServiceMobileImpl implements IServiceMobile {
	 private ICustomerDAO mobileDAO;
	 
	 public ServiceMobileImpl(){
		 mobileDAO=new MobileDAOImpl();
	 }
	@Override
	public List<MobileBean> viewAll() throws MobilePurchaseException {
		List<MobileBean> mobileList = mobileDAO.viewAll();		
		return mobileList;
	}

	@Override
	public boolean deleteMobile(int mobileId) throws MobilePurchaseException {
		IPurchaseDetailsDAo purchaseDetailsDAO = new PurchaseDetailsDAOImpl();
		boolean isPurchaseDeleted=purchaseDetailsDAO.deletePurchaseDetails(mobileId);
		boolean isDeleted = mobileDAO.deleteMobile(mobileId);
		
		return (isDeleted && isPurchaseDeleted);
	}

	@Override
	public List<MobileBean> search(float minPrice, float maxPrice)
			throws MobilePurchaseException {
		List<MobileBean> mobileList = mobileDAO.search(minPrice,maxPrice);
		
		return mobileList;
	}
	public boolean isValidMobileId(int mobileId)throws MobilePurchaseException{
		boolean isValid=false;
		String mobile=Integer.toString(mobileId);

		String pattern="[\\d]{4}";		
		Pattern pattern1 = Pattern.compile(pattern);
		Matcher matcher = pattern1.matcher(mobile);
	isValid=	matcher.matches();
		//isValid=Pattern.matches(mobile, pattern);
		if(!isValid){
			throw new MobilePurchaseException("Mobile Id must be 4 digits long");
		}
		
		return isValid;
	}

}
