package com.capgemini.cab.service;

import java.util.List;

import com.capgemini.cab.bean.MobileBean;
import com.capgemini.cab.exception.MobilePurchaseException;

public interface IServiceMobile {
	
	public List<MobileBean> viewAll()throws MobilePurchaseException;
	
	public boolean deleteMobile(int mobileId) throws MobilePurchaseException;
	
	public List<MobileBean>search(float minPrice,float maxPrice)throws MobilePurchaseException;
}
